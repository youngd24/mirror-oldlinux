/* $Id: syscall.h,v 1.1 1996/03/20 20:08:39 paul Exp $ */

#ifndef	___sys_syscall_h
#define	___sys_syscall_h

#ifdef SOLARIS

#include <sys/syscall.h>

#else

#include <syscall.h>  /* includes the SunOS <syscall.h> */

#define SYS_sigcleanup  139   /* omitted from the SunOS syscall.h */

#endif /* SOLARIS */

#endif	/* !___sys_syscall_h */
