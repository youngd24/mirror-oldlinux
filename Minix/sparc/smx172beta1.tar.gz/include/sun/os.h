/* $Id: os.h,v 1.1 1996/03/20 20:08:33 paul Exp $ */
/*
 * Various constants used in determining whether SunOS or Solaris is
 * being used.
 */


SYS_UNAME 	= 189
SOLARIS_ERR 	= 89

SOL_SYSCALL	= 8

SOL_sigprocmask = 95
SOL_getpid 	= 20
SOL_kill	= 37
SOL_SIGUSR1	= 16
SOL_SIGUSR2	= 17
SOL_SIG_SETMASK = 3

