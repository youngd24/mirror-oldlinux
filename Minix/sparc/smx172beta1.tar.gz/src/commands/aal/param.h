/*
 * (c) copyright 1987 by the Vrije Universiteit, Amsterdam, The Netherlands.
 * See the copyright notice in the ACK home directory, in the file "Copyright".
 */
/* $Header: /home/paul/CVS/minix1.7/src/commands/aal/param.h,v 1.1.1.1 1995/11/10 00:22:18 paul Exp $ */

#define SSIZE 1024
