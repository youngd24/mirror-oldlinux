/* libmain - flex run-time support library "main" function */

/* $Header: /home/paul/CVS/minix1.7/src/commands/flex-2.3.7/libmain.c,v 1.1.1.1 1995/11/10 00:23:35 paul Exp $ */

extern int yylex();

int main( argc, argv )
int argc;
char *argv[];

    {
    return yylex();
    }
