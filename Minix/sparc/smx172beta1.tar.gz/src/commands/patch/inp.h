/* $Header: /home/paul/CVS/minix1.7/src/commands/patch/inp.h,v 1.1.1.1 1995/11/10 00:22:49 paul Exp $
 *
 * $Log: inp.h,v $
 * Revision 1.1.1.1  1995/11/10 00:22:49  paul
 * The minix 1.7.1 source ftp'ed from Amsterdam mid-Novemeber 1995.
 *
 * Revision 2.0  86/09/17  15:37:25  lwall
 * Baseline for netwide release.
 * 
 */

EXT LINENUM input_lines INIT(0);	/* how long is input file in lines */
EXT LINENUM last_frozen_line INIT(0);	/* how many input lines have been */
					/* irretractibly output */

_PROTOTYPE(bool rev_in_string , (char *string ));
_PROTOTYPE(void scan_input , (char *filename ));
_PROTOTYPE(bool plan_a , (char *filename )); 
_PROTOTYPE(void plan_b , (char *filename ));
_PROTOTYPE(char *ifetch , (Reg1 LINENUM line , int whichbuf ));
_PROTOTYPE(void re_input , (void));
