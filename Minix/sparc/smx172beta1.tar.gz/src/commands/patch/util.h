/* $Header: /home/paul/CVS/minix1.7/src/commands/patch/util.h,v 1.1.1.1 1995/11/10 00:22:50 paul Exp $
 *
 * $Log: util.h,v $
 * Revision 1.1.1.1  1995/11/10 00:22:50  paul
 * The minix 1.7.1 source ftp'ed from Amsterdam mid-Novemeber 1995.
 *
 * Revision 2.0  86/09/17  15:40:06  lwall
 * Baseline for netwide release.
 * 
 */

/* and for those machine that can't handle a variable argument list */

#ifdef CANVARARG

#define say1 say
#define say2 say
#define say3 say
#define say4 say
#define ask1 ask
#define ask2 ask
#define ask3 ask
#define ask4 ask
#define fatal1 fatal
#define fatal2 fatal
#define fatal3 fatal
#define fatal4 fatal

#else /* hope they allow multi-line macro actual arguments */

#ifdef lint

#define say1(a) say(a, 0, 0, 0)
#define say2(a,b) say(a, (b)==(b), 0, 0)
#define say3(a,b,c) say(a, (b)==(b), (c)==(c), 0)
#define say4(a,b,c,d) say(a, (b)==(b), (c)==(c), (d)==(d))
#define ask1(a) ask(a, 0, 0, 0)
#define ask2(a,b) ask(a, (b)==(b), 0, 0)
#define ask3(a,b,c) ask(a, (b)==(b), (c)==(c), 0)
#define ask4(a,b,c,d) ask(a, (b)==(b), (c)==(c), (d)==(d))
#define fatal1(a) fatal(a, 0, 0, 0)
#define fatal2(a,b) fatal(a, (b)==(b), 0, 0)
#define fatal3(a,b,c) fatal(a, (b)==(b), (c)==(c), 0)
#define fatal4(a,b,c,d) fatal(a, (b)==(b), (c)==(c), (d)==(d))

#else /* lint */
    /* if this doesn't work, try defining CANVARARG above */
#define say1(a) say(a, Nullch, Nullch, Nullch)
#define say2(a,b) say(a, b, Nullch, Nullch)
#define say3(a,b,c) say(a, b, c, Nullch)
#define say4 say
#define ask1(a) ask(a, Nullch, Nullch, Nullch)
#define ask2(a,b) ask(a, b, Nullch, Nullch)
#define ask3(a,b,c) ask(a, b, c, Nullch)
#define ask4 ask
#define fatal1(a) fatal(a, Nullch, Nullch, Nullch)
#define fatal2(a,b) fatal(a, b, Nullch, Nullch)
#define fatal3(a,b,c) fatal(a, b, c, Nullch)
#define fatal4 fatal

#endif /* lint */

/* if neither of the above work, join all multi-line macro calls. */
#endif

EXT char serrbuf[BUFSIZ];		/* buffer for stderr */

_PROTOTYPE(int move_file , (char *from , char *to ));
_PROTOTYPE(void copy_file , (char *from , char *to ));
_PROTOTYPE(char *savestr , (Reg1 char *s ));
void say();
void fatal();
void ask();
_PROTOTYPE(void set_signals , (int reset ));
_PROTOTYPE(void ignore_signals , (void));
_PROTOTYPE(void makedirs , (Reg1 char *filename , bool striplast ));
_PROTOTYPE(char *fetchname , (char *at , int strip_leading , int assume_exists ));
