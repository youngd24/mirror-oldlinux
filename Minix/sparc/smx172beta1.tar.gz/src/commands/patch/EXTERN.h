/* $Header: /home/paul/CVS/minix1.7/src/commands/patch/EXTERN.h,v 1.1.1.1 1995/11/10 00:22:49 paul Exp $
 *
 * $Log: EXTERN.h,v $
 * Revision 1.1.1.1  1995/11/10 00:22:49  paul
 * The minix 1.7.1 source ftp'ed from Amsterdam mid-Novemeber 1995.
 *
 * Revision 2.0  86/09/17  15:35:37  lwall
 * Baseline for netwide release.
 * 
 */

#undef EXT
#define EXT extern

#undef INIT
#define INIT(x)

#undef DOINIT
