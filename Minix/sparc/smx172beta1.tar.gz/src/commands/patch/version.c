/* $Header: /home/paul/CVS/minix1.7/src/commands/patch/version.c,v 1.1.1.1 1995/11/10 00:22:50 paul Exp $
 *
 * $Log: version.c,v $
 * Revision 1.1.1.1  1995/11/10 00:22:50  paul
 * The minix 1.7.1 source ftp'ed from Amsterdam mid-Novemeber 1995.
 *
 * Revision 2.0  86/09/17  15:40:11  lwall
 * Baseline for netwide release.
 * 
 */

#include "EXTERN.h"
#include "common.h"
#include "util.h"
#include "INTERN.h"
#include "patchlevel.h"
#include "version.h"

/* Print out the version number and die. */

void
version()
{
    extern char rcsid[];

#ifdef lint
    rcsid[0] = rcsid[0];
#else
    fatal3("%s\nPatch level: %d\n", rcsid, PATCHLEVEL);
#endif
}
