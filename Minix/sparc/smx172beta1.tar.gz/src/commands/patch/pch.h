/* $Header: /home/paul/CVS/minix1.7/src/commands/patch/pch.h,v 1.1.1.1 1995/11/10 00:22:50 paul Exp $
 *
 * $Log: pch.h,v $
 * Revision 1.1.1.1  1995/11/10 00:22:50  paul
 * The minix 1.7.1 source ftp'ed from Amsterdam mid-Novemeber 1995.
 *
 * Revision 2.0.1.1  87/01/30  22:47:16  lwall
 * Added do_ed_script().
 * 
 * Revision 2.0  86/09/17  15:39:57  lwall
 * Baseline for netwide release.
 * 
 */

EXT FILE *pfp INIT(Nullfp);		/* patch file pointer */
#ifdef SMALL
EXT FILE *sfp INIT(Nullfp);		/* string file pointer */
#endif

_PROTOTYPE(void re_patch , (void));
_PROTOTYPE(void open_patch_file , (char *filename ));
_PROTOTYPE(void set_hunkmax , (void));
_PROTOTYPE(void grow_hunkmax , (void));
_PROTOTYPE(bool there_is_another_patch , (void));
_PROTOTYPE(int intuit_diff_type , (void));
_PROTOTYPE(void next_intuit_at , (long file_pos , long file_line ));
_PROTOTYPE(void skip_to , (long file_pos , long file_line ));
_PROTOTYPE(bool another_hunk , (void));
_PROTOTYPE(char *pgets , (char *bf , int sz , FILE *fp ));
_PROTOTYPE(bool pch_swap , (void));
_PROTOTYPE(LINENUM pch_first , (void));
_PROTOTYPE(LINENUM pch_ptrn_lines , (void));
_PROTOTYPE(LINENUM pch_newfirst , (void));
_PROTOTYPE(LINENUM pch_repl_lines , (void));
_PROTOTYPE(LINENUM pch_end , (void));
_PROTOTYPE(LINENUM pch_context , (void));
_PROTOTYPE(short pch_line_len , (LINENUM line ));
_PROTOTYPE(char pch_char , (LINENUM line ));
_PROTOTYPE(char *pfetch , (LINENUM line ));
_PROTOTYPE(LINENUM pch_hunk_beg , (void));
_PROTOTYPE(void do_ed_script , (void));
#ifdef SMALL
_PROTOTYPE(long saveStr , (char *string , short *length ));
_PROTOTYPE(void strEdit , (long pos , int from , int to ));
#endif
