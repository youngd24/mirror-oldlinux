/* $Header: /home/paul/CVS/minix1.7/src/commands/patch/version.h,v 1.1.1.1 1995/11/10 00:22:50 paul Exp $
 *
 * $Log: version.h,v $
 * Revision 1.1.1.1  1995/11/10 00:22:50  paul
 * The minix 1.7.1 source ftp'ed from Amsterdam mid-Novemeber 1995.
 *
 * Revision 2.0  86/09/17  15:40:14  lwall
 * Baseline for netwide release.
 * 
 */

_PROTOTYPE(void version , (void));
